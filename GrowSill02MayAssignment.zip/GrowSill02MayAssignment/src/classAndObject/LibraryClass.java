package classAndObject;

/*
Create a class Library with an instance variable libraryName.
Create a default constructor to print "Welcome to the Library!".
Create a method showLocation() which prints "This library is located in Mumbai".
Create an object in main() and call both.
 */

class Library {
	
	static String libraryName = "OXFORD LIBRARY";
	
    Library() {
    	System.out.println("Welcome to the Library");
	}
    
    void showLocation() {
    	System.out.println("This library is located in Mumbai");
    }
	
}

public class LibraryClass {

	public static void main(String[] args) {
       
		Library obj = new Library();
		System.out.println(Library.libraryName);
		obj.showLocation();
		
	}

}
