package Aggregation;

/*
 Create a class Engine with a method engineInfo().
Create a class Car that has-a Engine object and uses it to show engine details.
Show aggregation in main method.
 */

class Engine{
	
	Engine(){
		
	}
	
	void engineInfo() {
		System.out.println("Engine Info");
	}
}

class Car {
	
	Car(){
		
	}
	
     void engineInfo() {
		System.out.println("Engine details");
	} 
}
public class AggregationClass {

	public static void main(String[] args) {

	}

}
