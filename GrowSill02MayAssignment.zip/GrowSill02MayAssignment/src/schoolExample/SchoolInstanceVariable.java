package schoolExample;

/*Create a class named school ,create name as their instance variables 
Create a default constructor of this class which will have a print statement to display the name of school 
Create a method inside the class which will display a message as "This School is based out of Kolkata"
Create a object under main method and call the constructor and the method */
	
	class SchoolInstance{
		
		String name = "GIG INTERNATIONAL SCHOOL";
		
		SchoolInstance(){
			
	  		 System.out.println("The school name is: " +name);

		}
		
		void displayDetails() {
			
	  		 System.out.println("This School is based out of Kolkata");

		}
		
	}
	
	public class SchoolInstanceVariable {
		
		public static void main(String[] args) {
			
			SchoolInstance obj = new SchoolInstance();
			obj.displayDetails();
		}

}
