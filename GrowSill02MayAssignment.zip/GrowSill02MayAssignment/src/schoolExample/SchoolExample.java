package schoolExample;
	
	/*create name, address,strength as their instance variables 
	Create two constructor one with two variables and one with all the three variables 
	Create a method that will display all the three parameters 
	create two object of this class and call the respective methods?*/
	
	class School {
		
		String name;
		String address;
		int strength;
		
		School(String name, String address){
			
			this.name = name;
			this.address = address;
		
		}
		
		School(String name, String address, int strength){
			
			this.name = name;
			this.address = address;
			this.strength = strength;
		
		}
       
       void display()
  	 {
  		 System.out.println(name);
  		System.out.println(address);
  		System.out.println(strength);
  	 }
	}
	

   public class SchoolExample {

	public static void main(String[] args) {
		
		School obj = new School("GIG SChool", "Bangalore");
		obj.display();
		
		School obj1 = new School("TISB SChool", "Mysore", 500);
		obj1.display();
		
	}
		

	

}
