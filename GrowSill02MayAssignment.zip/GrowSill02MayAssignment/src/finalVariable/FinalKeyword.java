package finalVariable;

/*
 Create a class Bank with a final variable IFSC and final method showIFSC().
Try creating a subclass HDFCBank and attempt overriding the final method (should show compile-time restriction).
Create a main method to demonstrate usage.
 */

class Bank {
	
	final String IFSC = "HDFC0001910";
	
	final void showIFSC() {
		
		System.out.println("IFSC " + IFSC);
		
	}
	
}

class HDFCBank extends Bank {
	
	
   final void showIFSC() {
		
		System.out.println("IFSC " + IFSC);
		
	}
	
	
}



public class FinalKeyword {

	public static void main(String[] args) {
		
		HDFCBank obj = new HDFCBank();
		obj.showIFSC();

	}

}
