package finalVariable;

/*Create a class GovernmentRules with a final variable MAX_WORKING_HOURS = 8
Try modifying it inside main and observe compile-time restriction.*/

class Rules{
	
	 final int MAX_WORKING_HOURS=8;
	
	void display()
	{
		MAX_WORKING_HOURS=30;
		System.out.println(MAX_WORKING_HOURS);
	}
	
}

public class GovernmentRules {

	public static void main(String[] args) {
		
		Rules obj = new Rules();
		obj.display();
	}

}
