package polymorphism;

/*
Create a class Camera with a method capture().
Create a subclass DSLCamera that overrides the method.
Use parent reference to call child object method (dynamic polymorphism).*/


class Camera{
	
	void capture() {
		
		System.out.println("Camera of SUPERCLASS");
	}
}

class DSLCamera extends Camera{
	
    void capture() {
		
		System.out.println("DSLCamera of SUBCLASS");
	}
}

public class CameraClass {
	
	public static void main(String[] args) {
		
		Camera obj = new DSLCamera();
		obj.capture();
		
	}
	

}
