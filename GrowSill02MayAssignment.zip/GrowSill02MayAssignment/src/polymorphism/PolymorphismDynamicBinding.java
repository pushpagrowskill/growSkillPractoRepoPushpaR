package polymorphism;

/*
 * Create a parent class Shape with a method area().
Create subclasses Rectangle and Circle and override the area() method.
Create a reference of Shape and assign objects of both subclasses one by one, calling area() each time.
 */

class Shape{
		
	void area() {
		System.out.println("Area of respective ");
	}
	
}

class Rectangle extends Shape{
	
	int l;
	int b;
	
	 Rectangle(int l , int b) {
		 this.l = l;
		 this.b = b;
	}
	
    void area() {
		int rectangle = l*b;
		System.out.println("Area of Rectangle  " + rectangle);
	}
}

class Circle extends Shape{
	
	int r;
   double pi=3.14;
   
    Circle(int r) {
    	this.r = r;	
    }
	
    void area() {
    double circle =  pi*r*r;
	System.out.println("Area of Circle " + circle);
	}
}

public class PolymorphismDynamicBinding {

	public static void main(String[] args) {
		
		Shape obj = new Rectangle(12,12);
		Shape obj1 = new Circle(2);
		
		obj.area();
		obj1.area();
		

	}

}
