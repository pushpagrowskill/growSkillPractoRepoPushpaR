package methodOverloading;

/*
 
Create a class LoanCalculator with two overloaded methods:

calculateLoan(int amount)

calculateLoan(int amount, double interestRate)
Print loan details accordingly. Call both methods from main.
 */


class LoanCalculator{
	
	void calculateLoan(int amount) {
		
		System.out.println("amount " + amount);
		
	}
	
	void calculateLoan(int amount, double interestRate) {
		
		System.out.println("amount " + amount + " " + "Interest " + interestRate);

	}
}

public class MethodOverloading {

	public static void main(String[] args) {
		
		LoanCalculator obj = new LoanCalculator();
		obj.calculateLoan(50000);
		obj.calculateLoan(40000, 12.5);

	}

}
