package methodOverloading;

/*
 * Create a class Calculator with overloaded methods add():
add(int a, int b)
add(double a, double b)
Call both methods inside the main method and print results.
 */
class Calculator{
	
	void add() {
		System.out.println("ADD");
	}
	
	int add(int x,int y)
	{
		return x+y;
	}
	
	double add(double a, double b) {	
		return a+b;
	}

}
public class MethodOverloading2 {

	public static void main(String[] args) {
		
		Calculator obj = new Calculator();
		obj.add();
		System.out.println(obj.add(1,2));
		System.out.println(obj.add(32, 32));

	}

}
