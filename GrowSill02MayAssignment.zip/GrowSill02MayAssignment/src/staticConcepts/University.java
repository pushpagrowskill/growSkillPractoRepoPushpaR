package staticConcepts;


/*Create a class University with:
 * Static variable country = "India"instance variable universityName
Print values using different objects to show static effect.*/

class B1{
	
	static String country = "India";
	String universityName;
	
	B1(String universityName){
		
		this.universityName = universityName;
		System.out.println("The university name is " +universityName);
		
	}
}

public class University {
	
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		B1 obj = new B1("VTU");
		B1 obj1 = new B1("BANGALORE UNIVERSITY");
		
		System.out.println("Country for obj1: " + B1.country);
	    System.out.println("Country for obj2: " + B1.country);
	    
	    //Change static variable 
	    
	    B1.country = "CANADA";
	    
		System.out.println("Country for obj1: " + B1.country);
	    System.out.println("Country for obj2: " + B1.country);
	    
	    

		
	}


}
