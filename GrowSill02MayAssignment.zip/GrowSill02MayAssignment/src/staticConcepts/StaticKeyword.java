package staticConcepts;

/*
 *Create a class Student having static variable collegeName and instance variables name and rollNo.
Write a method to print both static and instance data.
Create multiple objects to show static value remains constant.
 */

class Student {
	
	static String collegeName = "SURANA COLLEGE";
	String name;
	int rollNo;
	
  Student (String name, int rollNo){
		
		this.name= name;
		this.rollNo= rollNo;	
	}
	
	void display() {
		System.out.println("college name is: " + collegeName);
		System.out.println("Student name is: " + name);
		System.out.println("Student roll no is: " + rollNo);
	} 
}


public class StaticKeyword {

	public static void main(String[] args) {
     
		Student obj = new Student("Pushpa", 1234);
		obj.display();
	}

}
