package shpaes;

class Shapes1{
	
	int length = 10;
	
	void square() {
		int area = length * length;
        System.out.println("Area of Square " + area);
	}
	
	void rectangle(int breadth) {
		  int area = length * breadth;
	      System.out.println("Area of Rectangle " + area);
	}
	
	void circle() {
		 double area = Math.PI * length * length;
	     System.out.println("Area of Circle " + area);
	}
	
}

public class Shapes {

	public static void main(String[] args) {
      
		Shapes1 obj = new Shapes1();
		obj.square();
		obj.rectangle(20);
		obj.circle();
	}

}
