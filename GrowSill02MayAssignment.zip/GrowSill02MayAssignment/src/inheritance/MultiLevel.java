package inheritance;

/*
 * Create three classes:

Device â†’ method start()

Mobile extends Device â†’ method calling()

SmartPhone extends Mobile â†’ method internet()
Create object of SmartPhone and call all methods.
 */

class Device {
	
	void start() {
	System.out.println("Device Android");
	}
}

class Mobile extends Device {
	
    void calling() {
     //super.start();
	System.out.println("Call to Customer care");
	}
}

class SmartPhone extends Mobile {
	
    void internet() {
   // super.calling();
 	System.out.println("Check for Internt");
	}
}

public class MultiLevel {
	
	public static void main(String[] args) {
		
		SmartPhone phone = new SmartPhone();
		phone.start();
		phone.internet();
		phone.calling();
		
		
	}


}
