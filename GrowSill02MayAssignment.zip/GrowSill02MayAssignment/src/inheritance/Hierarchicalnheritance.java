package inheritance;

/*
 * 
Create a class Course with a method courseInfo().
Create subclasses Science, Commerce, and Arts each with their own method.
Create objects of each and call methods to show hierarchy.
 */

class Course {
	
	void courseInfo(){
		
		System.out.println("Course details of each group");
	}
}

class Science extends Course{
	
	    void courseScienceInfo(){
		super.courseInfo();
		System.out.println("Course details of Science belongs to ENgineering and doctor");

	}

}

class Commerce extends Course{
	
	void courseCommerceInfo(){
		super.courseInfo();
		System.out.println("Course details of commerce belongs to business and banking");

	}

}

class Arts extends Course {
	
	void courseArtsInfo(){
		super.courseInfo();
		System.out.println("Course details of Arts belongs to public sector exams");

	}

}
public class Hierarchicalnheritance {

	public static void main(String[] args) {
		
		Science obj = new Science();
		obj.courseScienceInfo();
		
		Commerce obj1 = new Commerce();
		obj1.courseCommerceInfo();
		
		Arts obj2 = new Arts();
		obj2.courseArtsInfo();

		
	}

}
