package constructorChaining;

/*
 Create a class Product having instance variables productId, productName, and price.
Implement:

A default constructor that prints "Product Created".

A parameterized constructor that initializes the product details.
Write a method displayProduct() to print product details.
Create both types of objects in the main method.
 */

class Product {
	
	int productId;
	String productName;
	int price;
	
	Product(){
		System.out.println("Product created");
	}
	
	Product(int productId, String productName, int price){
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}
	
	void displayProduct() {
		System.out.println("Product ID " + productId + " Name " + productName + " Price " + price);
	}
	
}
public class DefaultConstructor {

	public static void main(String[] args) {
		
		Product obj = new Product();
		obj.displayProduct();
		
		Product obj1 = new Product(11,"Gold", 15000);
		obj1.displayProduct();

	}

}
