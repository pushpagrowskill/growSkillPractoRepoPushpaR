package encapsulation;

/*
 Create a class named Employee with private instance variables empId, empName, and salary.
Provide public getters and setters for all variables.
Create a method displayDetails() to print employee details.
Create an object in the main method and assign values using setters then display them.
 */

class Employee {
	
	private int empId;
	private String empName;
	private float salary;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	void displayDetails() {
		System.out.println("Employee ID is: " + empId);
		System.out.println("Employee Name is: " + empName);
		System.out.println("Employee Salary is: " + salary);	
   }
}

public class Encapsulation2 {

	/*
	 * public static void main(String[] args) {
	 * 
	 * Employee obj = new Employee();
	 * 
	 * obj.setEmpId(9876567); System.out.println(obj.getEmpId());
	 * 
	 * obj.setEmpName("Pushpa R"); System.out.println(obj.getEmpName());
	 * 
	 * obj.setSalary(2200000); System.out.println(obj.getSalary());
	 * 
	 * 
	 * }
	 */
	
public static void main(String[] args) {
		
		Employee obj = new Employee();
		obj.setEmpId(9876567);
		obj.setEmpName("Pushpa R");
		obj.setSalary(2200000);
		obj.displayDetails();
		

	}

}
