package methodOverridng;

/*
 *Create a base class Hospital with a method emergencyService().
Create a subclass CityHospital that overrides the method and calls parent method using super.emergencyService().
Demonstrate overriding in main.
 */


class Hospital {
	
	void emergencyService() {
		System.out.println("EMERGENCY SERVICE OF HOSPITAL");
	}
	
}

class CityHospital extends Hospital{
	
     void emergencyService() {
    	 super.emergencyService();
		System.out.println("EMERGENCY SERVICE OF CITY HOSPITAL");
	}
}


public class MethodOverridingWithSuper {
	
	public static void main(String[] args) {
		
		CityHospital obj = new CityHospital();
		obj.emergencyService();
		
		Hospital ref = new CityHospital();
		ref.emergencyService();
	}


}
