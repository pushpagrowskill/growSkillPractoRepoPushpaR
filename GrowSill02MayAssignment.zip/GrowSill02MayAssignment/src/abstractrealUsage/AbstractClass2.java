package abstractrealUsage;

/*
 * Create an abstract class Animal with an abstract method sound().
Create two subclasses Dog and Cat and provide implementation for sound() method.
Create objects and call sound() for each.
 */

abstract class Animal{
	
	abstract void sound();
	
}

class Dog extends Animal{

	@Override
	void sound() {
		System.out.println("DOG BARKS");
	}
}

class Cat extends Animal{

	@Override
	void sound() {		
		System.out.println("CAT MEOW");
	}
}

public class AbstractClass2 {

	public static void main(String[] args) {
		
		Cat obj = new Cat();
		obj.sound();
		
		Dog obj1 = new Dog();
		obj1.sound();

	}

}
