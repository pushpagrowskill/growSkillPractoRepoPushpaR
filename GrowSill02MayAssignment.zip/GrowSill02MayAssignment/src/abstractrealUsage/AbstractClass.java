package abstractrealUsage;

/*
Create an abstract class Employee with:

abstract method: calculateSalary()

concrete method: employeeDetails()
Subclass FullTimeEmployee and PartTimeEmployee implementing salary calculation logic differently.*/


abstract class Employee {
	
	String employeeName;
	String companyID;
	String companyName;
	
    abstract void calculateSalary();
    
    void employeeDetails() {
    	System.out.println("details of employee");
    	System.out.println(employeeName);
    	System.out.println(companyID);
    	System.out.println(companyName);
    }
	
}

class FullTimeEmployee extends Employee {	

	@Override
	void calculateSalary() {
		
	}
	
	
}

class PartTimeEmployee extends Employee {

	@Override
	void calculateSalary() {
		
	}	
	
	
}


public class AbstractClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
