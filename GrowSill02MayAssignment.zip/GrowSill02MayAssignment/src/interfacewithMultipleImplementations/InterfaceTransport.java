package interfacewithMultipleImplementations;

/*Create an interface Transport with method booking().
Implement it in Bus and Flight classes.
Call using interface reference.8*/


interface Transport{
	
	void booking(int fare, String partner, String time);
}

class Bus implements Transport{

	@Override
	public void booking(int fare, String partner, String time)
	{
		System.out.println("Booked bus for SHirdi " + fare + " " + partner + " " + time);
	}
}

class Flight implements Transport{

	@Override
	public void booking(int fare, String partner, String time)
	{
		System.out.println("Booked Flight for SHirdi " + fare + " " + partner+ " " + time);

	}
}


public class InterfaceTransport {
	
	public static void main(String[] args) {
		
		Transport ref = new Bus();
		ref.booking(5000, "REDBUS", "12:30 AM");
		Transport ref1 = new Flight();
		ref1.booking(14000, "AIR INDIA", "12:30 AM");

	}

}
