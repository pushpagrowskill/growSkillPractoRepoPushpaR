package interfacewithMultipleImplementations;

/*
Create an interface Payment with a method makePayment().
Create two classes UPI and CreditCard implementing this interface and define their own payment messages.
Call the method through interface reference.
 */

interface Payment{
	
	void makePayment();
}

class UPI implements Payment{

	@Override
	public void makePayment() {
		System.out.println("Made payment using UPI ID");
	}
}

class CreditCard implements Payment{

	@Override
	public void makePayment() {
		System.out.println("Made payment using Credit card");
	}
}

public class InterfaceImplementation {

	public static void main(String[] args) {
		Payment obj = new UPI();
		obj.makePayment();
		Payment obj1 = new CreditCard();
		obj1.makePayment();

	}

}
