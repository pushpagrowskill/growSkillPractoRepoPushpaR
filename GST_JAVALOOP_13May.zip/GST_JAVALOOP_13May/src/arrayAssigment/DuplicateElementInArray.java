package arrayAssigment;

import java.util.Scanner;

public class DuplicateElementInArray {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        // Input array size
        System.out.print("Enter size of array: ");
        int size = sc.nextInt();

        int[] arr = new int[size];

        // Input array elements
        System.out.println("Enter array elements:");

        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("Duplicate Elements are:");

        // Find duplicates
        for (int i = 0; i < size; i++) {

            for (int j = i + 1; j < size; j++) {

                if (arr[i] == arr[j]) {

                    System.out.println(arr[i]);
                    break;
                }
            }
        }

        sc.close();
    }
}