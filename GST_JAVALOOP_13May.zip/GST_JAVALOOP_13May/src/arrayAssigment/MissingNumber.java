package arrayAssigment;

import java.util.Scanner;

public class MissingNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

        // Size of array (N-1 elements)
        System.out.print("Enter size of array: ");
        int size = sc.nextInt(); //size= 6

        int[] arr = new int[size];

        System.out.println("Enter array elements:"); //{1,2,3,5,6,7}

        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        // N will be size + 1
        int n = size + 1; //n = 6+1 = 7

        // Sum of numbers from 1 to N
        int totalSum = n * (n + 1) / 2; // 6*7/2 = 21

        // Sum of array elements
        int arraySum = 0;

        for (int i = 0; i < size; i++) { //i=0; 0<6; //1<6
            arraySum += arr[i]; // 0= 1 arr[1] = 2 
        }

        // Missing number
        int missingNumber = totalSum - arraySum;

        System.out.println("Missing Number is: " + missingNumber);

        sc.close();
    }
}