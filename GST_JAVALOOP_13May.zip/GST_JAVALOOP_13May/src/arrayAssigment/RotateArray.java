package arrayAssigment;

public class RotateArray {

	public static void main(String[] args) {
		
		 int[] arr = {1,9,2,1,8,0};
	     int length = arr.length;

	        // Input K
	        System.out.print("Enter K value: ");
	        int k = 5;

	        // Handle K greater than array size
	        k = k % length;

	        // Left Rotation
	        for (int i = 0; i < k; i++) {

	            int first = arr[0];

	            for (int j = 0; j < length - 1; j++) {
	                arr[j] = arr[j + 1];
	            }

	            arr[length - 1] = first;
	        }

	        // Print rotated array
	        System.out.println("Array after Left Rotation:");

	        for (int i = 0; i < length; i++) {
	            System.out.print(arr[i] + " ");
	        }
	    }
}
