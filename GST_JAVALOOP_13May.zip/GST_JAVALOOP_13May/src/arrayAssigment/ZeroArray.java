package arrayAssigment;

public class ZeroArray {

	public static void main(String[] args) {
		
		  int[] arr = {1,0,2,0,8,7};
		     int size = arr.length;

	        // Position for non-zero elements
	        int index = 0;

	        // Move non-zero elements to front
	        for (int i = 0; i < size; i++) {

	            if (arr[i] != 0) {
	                arr[index] = arr[i];
	                index++;
	            }
	        }

	        // Fill remaining positions with zeros
	        while (index < size) {
	            arr[index] = 0;
	            index++;
	        }

	        // Print updated array
	        System.out.println("Array after moving zeros to end:");

	        for (int i = 0; i < size; i++) {
	            System.out.print(arr[i] + " ");
	        }
	    }
	}