package arrayAssigment;

import java.util.Scanner;

public class SeconlargestElement {

	public static void main(String[] args) {
		
		  Scanner sc = new Scanner(System.in);

	        // Input array size
	        System.out.print("Enter number of elements: ");
	        int n = sc.nextInt();

	        int[] arr = new int[n];

	        // Input array elements
	        System.out.println("Enter array elements:"); //{1,9,3,7,2}

	        for (int i = 0; i < n; i++) {
	            arr[i] = sc.nextInt();
	        }

	        // Assume first element as largest
	        int largest = arr[0];
	        int secondLargest = arr[0];

	        // Find largest and second largest
	        for (int i = 1; i < n; i++) { // i=1; 1<5    //i=2; 2<5

	            if (arr[i] > largest) {      //arr[1] > arr[0] 9>1 // arr[2] > 9
	                secondLargest = largest;  // second = 1
	                largest = arr[i];         // largest = 9
	            } 
	            else if (arr[i] > secondLargest && arr[i] != largest) {// 3>1 3!=9
	                secondLargest = arr[i]; //1=3
	            }
	        }

	        // Display result
	        System.out.println("Second Largest Element: " + secondLargest);

	        sc.close();
	    }

}
