package arrayAssigment;

public class RemoveDuplicateElements {

	public static void main(String[] args) {
		
		
		 int[] arr = {1,9,2,1,8,0};
	     int length = arr.length;
	     
        // Remove duplicates
        System.out.println("Array after removing duplicates:");

        for (int i = 0; i < length; i++) { //1=0; 0<6 1<6

            boolean isDuplicate = false;

            // Check if element appeared before
            for (int j = 0; j < i; j++) {     //j=0 ; 0<1  j=1 1<2
                if (arr[i] == arr[j]) {      //1==1        9==9
                    isDuplicate = true;     
                    break;
                }
            }

            // Print only unique elements
            if (!isDuplicate) {                  //9  //2 //1 //8 //0 
                System.out.print(arr[i] + " ");
            }
        }
        }
}
