package arrayAssigment;

public class ReverseArray {

	public static void main(String[] args) {
		

	        int[] arr = {1,9,2,3,8,0}; //0,1,2,3,4,5 //0,8,3,2,9,1
	        int length = arr.length;

	        // Reverse array without another array
	        int start = 0;
	        int end = length - 1; //end = 5

	        while (start < end) { //0<5          1<4  2<3   3<2

	            // Swap elements
	            int temp = arr[start];  //temp = 1            //temp = 9   temp = 2
	            arr[start] = arr[end];  //arr[0] = 0      //arr[1] = 8     arr[2] = 2
	            arr[end] = temp;       //arr[5] = 1         //arr[4] = 9    arr[3] = 3
 
	            start++;              //start =1      //2   //3
	            end--;                //end 4         //3   //2
	        } 

	        // Display reversed array
	        System.out.println("Reversed Array:");

	        for (int i = 0; i < length; i++) {
	            System.out.print(arr[i] + " ");
	        }
	}

}
