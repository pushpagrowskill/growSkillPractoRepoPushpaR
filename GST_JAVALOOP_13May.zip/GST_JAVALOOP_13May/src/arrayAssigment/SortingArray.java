package arrayAssigment;

import java.util.Scanner;

public class SortingArray {

	public static void main(String[] args) {
		
		 Scanner sc = new Scanner(System.in);

	        // Input array size
	        System.out.print("Enter size of array: ");
	        int size = sc.nextInt(); //size= 5

	        int[] arr = new int[size];

	        // Input array elements
	        System.out.println("Enter array elements:"); //{1,9,7,3,2}

	        for (int i = 0; i < size; i++) {
	            arr[i] = sc.nextInt();
	        }

	        for (int i = 0; i < size - 1; i++) { //i=0; 0<4;

	            for (int j = 0; j < size - 1 - i; j++) { //j=0; 0<4 1; 1<

	                if (arr[j] > arr[j + 1]) { //if(arr[0]>arr[1]) 1>9

	                    // Swap elements
	                    int temp = arr[j]; //temp = 9
	                    arr[j] = arr[j + 1]; //arr[0] = 9
	                    arr[j + 1] = temp; //
	                }
	            }
	        }

	        // Print sorted array
	        System.out.println("Sorted Array:");

	        for (int i = 0; i < size; i++) {
	            System.out.print(arr[i] + " ");
	        }

	        sc.close();
	    }
	}