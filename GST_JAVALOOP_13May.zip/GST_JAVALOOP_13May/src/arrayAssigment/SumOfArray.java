package arrayAssigment;

public class SumOfArray {
	
	  public static void main(String[] args) {

		  int[] arr = {1,9,2,1,8,0};
		     int size = arr.length;

	        int target = 10;

	        boolean found = false;

	        // Find pairs
	        for (int i = 0; i < size; i++) {

	            for (int j = i + 1; j < size; j++) {

	                if (arr[i] + arr[j] == target) {

	                    System.out.println(
	                        "Pair found: " + arr[i] + " + " + arr[j] + " = " + target
	                    );

	                    found = true;
	                }
	            }
	        }

	        // If no pair found
	        if (!found) {
	            System.out.println("No pair found.");
	        }
	  }
}