package stringAssignment;

public class RemoveDuplicates {

	public static void main(String[] args) {
		
		   String str = "pusp";
	        char[] chars = str.toCharArray();

	        System.out.print("After removing duplicates: ");

	        for (int i = 0; i < chars.length; i++) { //i=0; 0<4

	            boolean isDuplicate = false;

	            for (int j = 0; j < i; j++) { //j=0 ; 0<0 1<0

	                if (chars[i] == chars[j]) { // 0==0
	                    isDuplicate = true;
	                    break;
	                }
	            }

	            if (!isDuplicate) {
	                System.out.print(chars[i]);
	            }
	        }
	    }
	}
