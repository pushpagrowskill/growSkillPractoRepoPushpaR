package stringAssignment;

public class StringVowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
