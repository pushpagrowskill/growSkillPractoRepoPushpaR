package stringAssignment;

public class NonRepeatedCharacter {

	public static void main(String[] args) {
		
		  String str = "pusp"; //length = 4
	        boolean found = false;

	        for (int i = 0; i < str.length(); i++) { //i=0; 0<4  i=1 , 1<4 

	            int count = 0;

	            for (int j = 0; j < str.length(); j++) { //j=0 , 0<4 1 1<4 2<4 3<4 4<4   j=0 ; 0<4

	                if (str.charAt(i) == str.charAt(j)) { // [0] = [0] [0]==[1] [0]=[2] [0]=[3] [1]==[0]
	                    count++; //count =1 
	                }
	            }

	            if (count == 1) {
	                System.out.println("First non-repeated character: " + str.charAt(i));
	                found = true;
	                break;
	            }
	        }

	        if (!found) {
	            System.out.println("No non-repeated character found.");
	        }
	    }
	}