package stringAssignment;

public class ReverseString {

	public static void main(String[] args) {
		
		String reverseString = "Java";
		String output = "";
		
		for(int i= reverseString.length()-1; i>=0; i--) {
			
			output = output + reverseString.charAt(i);
			
		}
		System.out.println("Reversed string " + output);
		
		if(reverseString.endsWith(output)) {
			System.out.println("Reversed string is palindrome " + output);
		}
		else {
			System.out.println("Reversed string is not palindrome " + output);
		}
	}
	

	
	
}
