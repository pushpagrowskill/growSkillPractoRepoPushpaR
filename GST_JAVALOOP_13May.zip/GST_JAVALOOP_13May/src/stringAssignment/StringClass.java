package stringAssignment;

public class StringClass {

	public static void main(String[] args) {

		String str = "Reverse";
        String reversed = "";

        for (int i = str.length() - 1; i >= 0; i--) { // length = 7 -1 = 6; 6>=0; 5 ;5>=0
            reversed = reversed + str.charAt(i);     //es
        }

        System.out.println("Original String: " + str);
        System.out.println("Reversed String: " + reversed);
    }
}
