package stringAssignment;

public class Countoccurence {

	public static void main(String[] args) {
		
		   String str = "pusp";
	        char[] chars = str.toCharArray();

	        System.out.println("Character Occurrences:");

	        for (int i = 0; i < chars.length; i++) { //i=0 ;0<4

	            int count = 1; // 1

	            if (chars[i] == '0') {//0==0
	                continue;
	            }

	            for (int j = i + 1; j < chars.length; j++) { //j= 1 ; 1<4; j= 2<4 3<4

	                if (chars[i] == chars[j]) { //p==u //p==s //p==p
	                    count++;   //1
	                    chars[j] = '0'; // Mark counted characters
	                }
	            }

	            System.out.println(chars[i] + " -> " + count);
	        }
	    }
	}