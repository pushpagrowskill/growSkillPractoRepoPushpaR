package stringAssignment;

public class DuplicateCharacters {

	public static void main(String[] args) {

		  String str = "qweeertyu";

	        char[] chars = str.toCharArray();

	        System.out.println("Duplicate characters are:");

	        for (int i = 0; i < chars.length; i++) {

	            int count = 1;

	            for (int j = i + 1; j < chars.length; j++) {

	                if (chars[i] == chars[j] && chars[i] != ' ') {
	                    count++;
	                    chars[j] = '0'; // Mark visited character
	                }
	            }

	            if (count > 1 && chars[i] != '0') {
	                System.out.println(chars[i]);
	            }
	        }
	    }
	}
