package stringAssignment;

public class StringPalindrome {

	public static void main(String[] args) {

		 String str = "madam";
	        String reversed = "";

	        // Reverse the string
	        for (int i = str.length() - 1; i >= 0; i--) {
	            reversed = reversed + str.charAt(i);
	        }

	        // Check palindrome
	        if (str.equals(reversed)) {
	            System.out.println(str + " is a Palindrome");
	        } else {
	            System.out.println(str + " is not a Palindrome");
	        }
	    }
	}
