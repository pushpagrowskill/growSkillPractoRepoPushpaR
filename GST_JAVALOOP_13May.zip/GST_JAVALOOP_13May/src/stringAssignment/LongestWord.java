package stringAssignment;

public class LongestWord {

	public static void main(String[] args) {
		
		 String sentence = "Java programmingg is very interesting";

	        // Split sentence into words
	        String[] words = sentence.split(" ");

	        String longestWord = "";

	        for (String word : words) {

	            if (word.length() > longestWord.length()) {
	                longestWord = word;
	            }
	        }

	        System.out.println("Longest Word: " + longestWord);
	        System.out.println("Length: " + longestWord.length());
	    }
	}