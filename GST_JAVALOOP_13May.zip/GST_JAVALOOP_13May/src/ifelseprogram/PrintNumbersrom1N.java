package ifelseprogram;

import java.util.Scanner;

public class PrintNumbersrom1N {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter the value of N: ");
        int n = sc.nextInt();

        // Print numbers from 1 to N
        for (int i = 1; i <= n; i++) {
            System.out.println(i);
        }

        sc.close();
	}

}
