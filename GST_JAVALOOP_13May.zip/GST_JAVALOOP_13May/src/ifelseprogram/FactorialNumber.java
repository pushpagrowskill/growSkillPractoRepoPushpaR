package ifelseprogram;

import java.util.Scanner;

public class FactorialNumber {

	public static void main(String[] args) {
		
		  Scanner sc = new Scanner(System.in);

	        System.out.print("Enter a number: ");
	        int number = sc.nextInt(); 
	        long factorial = 1;

	        // for loop to calculate factorial
	        for (int i = 1; i <= number; i++) { //i=1; 1<=4; //i=2; 2<=4 // 3<=4 //4<=4
	            factorial = factorial * i; //1*1 = 1 // 1*2 = 2 //2*3 = 6 // 6*4 = 24
	        }
	        System.out.println("Factorial of " + number + " is: " + factorial);
	        sc.close();
	}

}
