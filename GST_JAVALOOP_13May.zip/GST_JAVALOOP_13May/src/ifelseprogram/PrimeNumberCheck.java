package ifelseprogram;

public class PrimeNumberCheck {

	public static void main(String[] args) {
		
	        int number = 11;
	        boolean isPrime = true;

	            // Loop to check divisibility
	            for (int i = 2; i < number/2; i++) { //11 ; 11<11/2 = 5 // 3<5

	                if (number % i == 0) { // 11%2 = 1
	                    isPrime = false;
	                    break;
	                }
	            }
	        if (isPrime) {
	            System.out.println(number + " is a Prime Number.");
	        } else {
	            System.out.println(number + " is not a Prime Number.");
	        }
	    }
	}
