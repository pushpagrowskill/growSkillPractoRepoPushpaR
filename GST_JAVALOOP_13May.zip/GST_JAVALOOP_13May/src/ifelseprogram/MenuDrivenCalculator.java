package ifelseprogram;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		
		 Scanner sc = new Scanner(System.in);

	        int choice;
	        double num1, num2, result;

	        do {
	            // Display menu
	            System.out.println("\n===== Calculator Menu =====");
	            System.out.println("1. Add");
	            System.out.println("2. Subtract");
	            System.out.println("3. Multiply");
	            System.out.println("4. Divide");
	            System.out.println("5. Exit");

	            System.out.print("Enter your choice: ");
	            choice = sc.nextInt();

	            switch (choice) {

	                case 1:
	                    System.out.print("Enter first number: ");
	                    num1 = sc.nextDouble();

	                    System.out.print("Enter second number: ");
	                    num2 = sc.nextDouble();

	                    result = num1 + num2;

	                    System.out.println("Result = " + result);
	                    break;

	                case 2:
	                    System.out.print("Enter first number: ");
	                    num1 = sc.nextDouble();

	                    System.out.print("Enter second number: ");
	                    num2 = sc.nextDouble();

	                    result = num1 - num2;

	                    System.out.println("Result = " + result);
	                    break;

	                case 3:
	                    System.out.print("Enter first number: ");
	                    num1 = sc.nextDouble();

	                    System.out.print("Enter second number: ");
	                    num2 = sc.nextDouble();

	                    result = num1 * num2;

	                    System.out.println("Result = " + result);
	                    break;

	                case 4:
	                    System.out.print("Enter first number: ");
	                    num1 = sc.nextDouble();

	                    System.out.print("Enter second number: ");
	                    num2 = sc.nextDouble();

	                    if (num2 != 0) {
	                        result = num1 / num2;
	                        System.out.println("Result = " + result);
	                    } else {
	                        System.out.println("Cannot divide by zero.");
	                    }
	                    break;

	                case 5:
	                    System.out.println("Exiting Calculator...");
	                    break;

	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }

	        } while (choice != 5);

	        sc.close();
	    }
}
