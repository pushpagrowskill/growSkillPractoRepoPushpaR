package ifelseprogram;

public class ReverseNumber {

	public static void main(String[] args) {
		
		int number = 121;
		int rev = 0;
		
		while(number!=0) //121!=0 // 12!=0 // 1!=0
		{
			int d = number%10; // 121%10 = 1 // 12%10 = 2 // 1%10  = 1
			rev = rev*10+d;    // 0*10+1 = 1 // 1*10+2 = 12 // 12*10 + 1 = 121
			number = number/10; // 121/10 = 12 // 12/10 = 1 // 1/10 = 0 
		}
		System.out.println(rev);
		
	}

}
