package ifelseprogram;

public class CountDigitsInNumber {

	public static void main(String[] args) {
		
	   int num = 12345;

        int count = 0;
        int temp = num;

        // Count digits using while loop
        while (temp != 0) {  // 12345!=0  1234 != 0 123!=0  12!=0  1!=0 0!=0
            temp = temp / 10; // 12345/10 = 1234   // 1234/10 = 123 // 123/10 = 12 //12/10 = 1 // 1/10 = 0
            count++;           // 1 //2 //3 //4 //5 
        }

        System.out.println("Number of digits: " + count); 
	}

}
