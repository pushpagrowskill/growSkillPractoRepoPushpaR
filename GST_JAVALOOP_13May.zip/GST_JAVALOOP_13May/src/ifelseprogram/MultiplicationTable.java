package ifelseprogram;

public class MultiplicationTable {

	public static void main(String[] args) {

	        int num = 12;

	        // Printing multiplication table
	        System.out.println("Multiplication Table of " + num + ":");

	        for (int i = 1; i <= 10; i++) {
	            System.out.println(num + " x " + i + " = " + (num * i));
	        }
	    }
	}