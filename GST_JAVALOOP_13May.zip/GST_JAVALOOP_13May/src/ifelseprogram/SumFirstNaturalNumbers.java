package ifelseprogram;

import java.util.Scanner;

public class SumFirstNaturalNumbers {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter the value of n: ");
        int n = sc.nextInt();

        int sum = 0;
        int i = 1;

        // Calculate sum using while loop
        while (i <= n) {
            sum = sum + i;
            i++;
        }

        // Display the result
        System.out.println("Sum of first " + n + " natural numbers is: " + sum);

        sc.close();
    }
	}